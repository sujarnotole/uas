<?php 
 require('header.php');
 ?>

 <?php
 include_once('sidebar.php');
 ?>
<?php
include_once('index.php');
 ?>
<?php
include_once('komen.php');
?>
 
 
 
 <?php
include_once 'footer.php';
 ?>
 