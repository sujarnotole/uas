<head>
	<meta charset="utf-8">
	<!-- pemanggilan file css -->
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta name="viewport" content="width=device-widget, initial-scale=1">
		<title>Kulgram</title>
</head>

<body>
	<!-- membuat header -->
	<div id="container">
		<header>
		<div  class="entry">
			<h2> TEKNOLOGI DESIGN WEB </h2>

		</div>
		</header>


		<nav>
			<ul>
				<li class="active"><a href="home.php" title="Home">Home</a></li>
				<li> <a href="profile.php" title="About"> About</a></li>
				<li> <a href="contact.html" title="Contact">Contact</a></li>
				<li> <a href="login.php" title="Login">Login</a></li>
			</ul>
		</nav>
