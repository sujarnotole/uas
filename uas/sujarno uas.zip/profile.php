<head>
	<meta charset="utf-8">
	<!-- pemanggilan file css -->
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta name="viewport" content="width=device-widget, initial-scale=1">
		<title>kulgram</title>
</head>
	<?php
 require('header.php');
 ?>
		<h1>My Profile</h1>
	<div class="pro" >
			<img src="image/satu.jpg" width=" 150px">
			<ul type="circle">
				<li>Nama	: Rudy Sucipto N</li>
				<li>Nim		: 311610437</li>
				<li>Kelas	: TI.16.B2</li>
			</ul>
	</div>
	<div class="data">
		<ul type="circle">
			<h2>Biodata Lengkap</h2>
			<li>Nama						:Rudy Sucipto Nugroho</li>
			<li>Jenis Kelamin		:Laki - Laki</li>
			<li>Ttl 						:Jakarta , 26 Desember 1995/li>
			<li>Alamat					:Bekasi</li>
			<li>Agama 					:Islam</li>
			<li>Kewarganegaraan :Indonesia</li>
			<li>No.hp 					:085869257356</li>
			<li>E-mail 					:rsn@mhs.pelitabangsa.ac.id</li>
		</ul>
	</div>
 <?php
include_once 'footer.php';
 ?>


</body>
</html>
