<div id="content">
			<div class="row">
				<div class="box">
					<img src="image/satu.jpg"  class="image-circle" />
					<h3>sujarno N</h3>
					<p>Mahasiswa Teknik Informatika Pelita Bangsa</p>
					<a href="#" class="btn btn-default"> View Detail</a>
				</div>
				<div class="box">
					<h3>Data Diri</h3>
					<p>NIM = 311610471</p>
					<p>Kelas = TI.16.B.2</p>
					<p>Github = <a href="https://github.com/sujarno">sujarno N</a></p>

				</div>


			</div>
			<hr class="divider" />
			<div class="entry">
				<h2> First Featurette Heading</h2>
				<img src="image/satu.jpg"/>
				<p>lorem ipsum dolor sit amet, cobnsectetur adipiscingelit, iaculis in nisi volutpat males</p>
				<hr class="divider" />
				<h2> First Featurette Heading</h2>
				<img src="image/satu.jpg"/>
				<p>lorem ipsum dolor sit amet, cobnsectetur adipiscingelit, iaculis in nisi volutpat males</p>
			</div>

		</div>
