<html>
<head>
<title>Untitled Document</title>
</head>
<body>
<form action=”input.php” name=”formsiswa” method=”post”>
<table>
<tr><td>no.induk</td><td><input name=”induk” type=”text” value=”" size=”25″ maxlength=”25″ /></td></tr>
<tr><td>nama anda</td><td><input name=”nama” type=”text” value=”" size=”25″ maxlength=”25″ /></td></tr>
<tr><td>email anda</td><td><input name=”email” type=”text” value=”" size=”25″ maxlength=”25″ /></td></tr>
<tr><td>komentar</td><td><textarea name=”komentar” cols=”25″ rows=”5″></textarea></td></tr>
<tr><td></td><td><input name=”save” type=”submit” value=”save” /></td></tr>
</table>
</form>
//di buat oleh enterprise2605
//afian2605@ymail.com
</body>
</html>